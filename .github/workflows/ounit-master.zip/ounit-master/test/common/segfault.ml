external cause_segfault: unit -> unit = "caml_cause_segfault"
