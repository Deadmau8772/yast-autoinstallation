[RFC3986](http://tools.ietf.org/html/rfc3986) URI parsing library.

Build requirements:
* [ocaml-re](http://github.com/avsm/ocaml-re) regular expression library.
* [oUnit](http://ounit.forge.ocamlcore.org/) unit testing library.

[![Build Status](https://travis-ci.org/mirage/ocaml-uri.png)](https://travis-ci.org/mirage/ocaml-uri)
