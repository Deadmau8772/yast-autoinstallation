Control file validation:
------------------------

Run command

    xmllint --noout --relaxng /usr/share/YaST2/control/control.rng *.xml

or simply

    make check

