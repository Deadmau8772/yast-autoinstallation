system-role-hpc-server
==============================

Extension package that lives in module and extend installation by roles provided by this module.

See also the [documentation for the `control.xml` file][1].

[1]: https://github.com/yast/yast-installation/blob/master/doc/control-file.md
