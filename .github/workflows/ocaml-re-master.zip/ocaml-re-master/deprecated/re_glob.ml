[@@@deprecated "Use Re.Glob"]

include Re.Glob
