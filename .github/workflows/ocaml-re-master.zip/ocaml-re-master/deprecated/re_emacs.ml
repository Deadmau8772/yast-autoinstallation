[@@@deprecated "Use Re.Emacs"]

include Re.Emacs
