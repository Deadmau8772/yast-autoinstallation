let string = "%%VERSION_NUM%%"
