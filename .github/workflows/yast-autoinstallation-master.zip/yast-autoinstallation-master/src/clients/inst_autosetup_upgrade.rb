require "autoinstall/clients/inst_autosetup_upgrade"

Y2Autoinstallation::Clients::InstAutosetupUpgrade.new.main
