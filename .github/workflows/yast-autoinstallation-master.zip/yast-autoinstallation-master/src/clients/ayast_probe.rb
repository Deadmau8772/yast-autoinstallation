require "autoinstall/clients/ayast_probe"
Y2Autoinstall::Clients::AyastProbe.new.main
