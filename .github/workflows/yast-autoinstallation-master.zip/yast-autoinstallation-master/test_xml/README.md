These are xml files for testing various aspects of autoyast. 
They are still also hosted on taylor.suse.de for testing.
taylor.suse.de has an apache runing and these files are in
directory <code>/srv/www/htdocs</code> on taylor.
