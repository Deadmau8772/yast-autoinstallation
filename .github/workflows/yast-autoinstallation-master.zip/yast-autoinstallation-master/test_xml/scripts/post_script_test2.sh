#!/bin/sh

echo "post script (network true) has run" > /tmp/post-script2-has-run

