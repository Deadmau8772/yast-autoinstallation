#!/bin/sh

echo "Testing file scripts with location" >> /etc/someconf.conf
df >> /etc/someconf.conf
cd /root
ls >> /etc/someconf.conf
