#!/bin/sh

echo "init script2 has run" > /tmp/init-script2-has-run

