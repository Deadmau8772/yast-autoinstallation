#!/bin/sh

echo "chroot script $0 (chroot false) has run" > /tmp/chroot-script-has-run
sleep 3 #000
